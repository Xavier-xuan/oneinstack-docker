============================================================
 Percona PAM authentication plugin For MySQL - Documentation
============================================================

Percona PAM authentication plugin for MySQL.

Introduction
============

.. toctree::
   :maxdepth: 1
   :glob:

   intro

Installation
============

.. toctree::
   :maxdepth: 2
   :glob:

   installation

User's Manual
=============

.. toctree::
   :maxdepth: 2
   :glob:

   manual

Miscellaneous
=============

.. toctree::
   :maxdepth: 1
   :glob:

   faq
   release-notes
   glossary

Indices and tables
==================

* :ref:`genindex`

* :ref:`search`

