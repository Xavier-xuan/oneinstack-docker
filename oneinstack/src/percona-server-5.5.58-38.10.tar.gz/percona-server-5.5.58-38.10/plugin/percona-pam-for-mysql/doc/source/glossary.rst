==========
 Glossary
==========

.. glossary::

   PAM
     Pluggable Authentication Module - allows integrating multiple authentication mechanisms which can be written independently of the underlying authentication scheme that's being used in the application.
